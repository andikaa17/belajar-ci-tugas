<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman F.A.Q
<?= $this->endSection() ?>